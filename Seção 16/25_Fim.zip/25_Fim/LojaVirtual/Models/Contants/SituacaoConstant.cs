﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LojaVirtual.Models.Contants
{
    public class SituacaoConstant
    {
        public const string Ativo = "A";
        public const string Desativado = "D";
    }
}
