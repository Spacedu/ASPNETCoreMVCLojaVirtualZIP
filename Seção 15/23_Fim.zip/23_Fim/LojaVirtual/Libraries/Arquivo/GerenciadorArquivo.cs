﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LojaVirtual.Libraries.Arquivo
{
    public class GerenciadorArquivo
    {
        public static void CadastrarImagemProduto(IFormFile file)
        {
            //TODO - Armazenar imagem em uma pasta.
        }

        public static void ExcluirImagemProduto()
        {
            //TODO - Deletar imagem na pasta.
        }
    }
}
