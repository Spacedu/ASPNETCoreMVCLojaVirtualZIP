﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LojaVirtual.Models
{
    public class Pacote
    {
        public int Largura { get; set; }
        public int Altura { get; set; }
        public int Comprimento { get; set; }
        public decimal Peso { get; set; }
    }
}
